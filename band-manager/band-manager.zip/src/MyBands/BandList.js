import React, { Component } from 'react';

class BandList extends Component {
  render() {
    return (
      <div className="BandList">
        
      </div>
    );
  }
}

export default BandList;